package com.enpoints.vehicle_ep;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VehicleEpApplication {

	public static void main(String[] args) {
		SpringApplication.run(VehicleEpApplication.class, args);
	}

}
