package com.Vehicledata;

public class Vehicle {

	public void setMake(String string) {
		// TODO Auto-generated method stub
		
	}

	public int[] getMake() {
		// TODO Auto-generated method stub
		return null;
	}

	public Object[] getId() {
		// TODO Auto-generated method stub
		return null;
	}

}
