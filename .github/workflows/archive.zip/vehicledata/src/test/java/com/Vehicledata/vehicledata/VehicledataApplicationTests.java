package com.Vehicledata.vehicledata;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VehicledataApplicationTests {

	@Test
	void contextLoads() {
	}

}
