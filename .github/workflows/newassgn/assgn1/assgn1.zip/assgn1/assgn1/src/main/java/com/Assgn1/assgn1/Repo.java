package com.Assgn1.assgn1;


import org.springframework.data.jpa.repository.JpaRepository;

public interface Repo extends JpaRepository<Message,Long> {
}
