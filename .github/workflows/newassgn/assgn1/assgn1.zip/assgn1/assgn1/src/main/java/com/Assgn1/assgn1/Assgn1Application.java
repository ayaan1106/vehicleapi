package com.Assgn1.assgn1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Assgn1Application {

	public static void main(String[] args) {
		SpringApplication.run(Assgn1Application.class, args);
	}

}
