package com.Assgn1.assgn1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Assgn1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
